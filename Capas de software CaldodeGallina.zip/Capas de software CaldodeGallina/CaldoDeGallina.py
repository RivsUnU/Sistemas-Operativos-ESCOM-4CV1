import os
import time

def abrir_archivos(ruta):
    for carpeta_raiz, subcarpetas, archivos in os.walk(ruta): #Recorre carpetas
        for archivo in archivos:
            ruta_archivo = os.path.join(carpeta_raiz, archivo) #construye ruta para archivos

            print(f"Abriendo archivo: {ruta_archivo}")
            os.startfile(ruta_archivo) #Abre archivos

            input(f"Presiona Enter cuando hayas cerrado {archivo} para abrir el siguiente: \n\n")

ruta_principal = os.path.join(os.path.expanduser("~"), "D:", "D:\Sistemas Operativos\Capas de software CaldodeGallina") #Colocar nombre de carpeta en el escritorio o la ruta que deseen

if os.path.exists(ruta_principal):
    abrir_archivos(ruta_principal) #Condicional para verificar existencia
else:
    print("La carpeta 'Practica10' no existe")