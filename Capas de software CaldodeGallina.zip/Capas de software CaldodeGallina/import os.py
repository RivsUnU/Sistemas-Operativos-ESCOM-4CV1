import os

def abrir_archivo(ruta):
    print(f"Abriendo archivo: {ruta}")
    os.startfile(ruta)  # Abre el archivo
    input(f"Presiona Enter cuando hayas cerrado el archivo para continuar...\n")

def abrir_en_orden(ruta_principal):
    carpetas_en_orden = ["Controladores de dispositivos", "Software modo usuario para ES"]  # Orden deseado
    for carpeta in carpetas_en_orden:
        ruta_carpeta = os.path.join(ruta_principal, carpeta)
        if os.path.exists(ruta_carpeta):
            print(f"\nAbriendo archivos en la carpeta: {carpeta}\n")
            for archivo in os.listdir(ruta_carpeta):
                ruta_archivo = os.path.join(ruta_carpeta, archivo)
                if os.path.isfile(ruta_archivo):  # Verifica que sea un archivo
                    abrir_archivo(ruta_archivo)
        else:
            print(f"La carpeta {carpeta} no existe en {ruta_principal}.\n")

# Ruta principal donde están las carpetas
ruta_principal = r"D:\Sistemas Operativos\Capas de software CaldodeGallina"  # Cambia esto según tu estructura

if os.path.exists(ruta_principal):
    abrir_en_orden(ruta_principal)
else:
    print(f"La carpeta principal '{ruta_principal}' no existe.")